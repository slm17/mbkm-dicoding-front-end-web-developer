import "regenerator-runtime";
import './css/style.css';
import main from "./script/data/main.js";

main();